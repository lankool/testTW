//
//  jsonSubclass.m
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 23/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import "jsonSubclass.h"
#import "PostJSON.h"

@implementation jsonSubclass
/* +(void) alertStatus:(NSString *)msg :(NSString *)title onView:(UIViewController *)viewController
{
    UIAlertController * alert=   [UIAlertController
                                     alertControllerWithTitle:title
                                     message:msg
                                     preferredStyle:UIAlertControllerStyleAlert];

       UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action)
                                   {
                                       //Handel your yes please button action here
                                       [alert dismissViewControllerAnimated:YES completion:nil];

                                   }];

       [alert addAction:okButton];

    [viewController presentViewController:alert animated:YES completion:nil];

    
} */


/*- (void) alertStatus:(NSString *)msg :(NSString *)title
{
    
    //UIViewController *viewController = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    UIAlertController *viewController = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];

    dispatch_async(dispatch_get_main_queue(), ^{
    [viewController presentViewController:viewController animated:YES completion:^{}];
    });
} */


-(void)postingDetailswithJSON:(NSString *)dataPass doSomethingWithCompletionHandler:(void(^)(BOOL status))handler  {
    
    //NSLog(@"DATA PASS %@", handler);
    
    // Create NSURLSession object.
    NSURLSession *session = [NSURLSession sharedSession];

    // Create a NSURL object.
    NSURL *url = [NSURL URLWithString:@"https://reqres.in/api/login"];
    NSLog(@"URL : %@", url);

    // Create post request object with the url.
    NSData *postData = [[NSData alloc]init];
    NSString *post = [[NSString alloc]initWithString:dataPass];
    NSLog(@"DATA PASS %@", dataPass);
    
   postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSLog(@"Data Conversion: %@", postData);
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
    //NSLog(@"POST LENGTH %@", postLength);
    
    // Set request method to POST.
    //request.HTTPMethod = @"POST";
    
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:postData];
    // Set post username and password data.
    //request.HTTPBody = postData;
    
    NSLog(@"The request %@", request);

    // Create the NSURLSessionDataTask post task object.
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        

       NSLog(@"NSSTRING %@",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
            
            // Print out the result JSON format data.
        NSLog(@"NSJSONSERIALIZATION %@", [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil]);
        
        //NSNotificationcentre
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        NSInteger statusCode = httpResponse.statusCode;
        if (statusCode >= 200 && statusCode < 300) {
            NSLog(@"Response ==> %ld", statusCode);
            
            BOOL status = YES;
            
            NSLog(@"Handler : %d",status);
            handler(status);

        }
        else {
            BOOL status = NO;
            
            NSLog(@"Handler : %d",status);
            handler(status);

            
            NSLog(@"USER NOT FOUND");
           //[self alertStatus:@"Logged in Failed." :@"Login Fail"];
        }
        
            }];
     [task resume];
    
    //function callback;

  //  PostJSON *message = [[PostJSON alloc] init];
           // set your message properties
   // NSDictionary *dict = [NSDictionary dictionaryWithObject:message forKey:@"message"];
   // [[NSNotificationCenter defaultCenter] postNotificationName:@"NotificationMessageEvent" object:nil userInfo:dict];
    
    // Execute the task
   
    
}

/* -(void)getContentMessage:(NSString *)memberDetail completed:(postRequestBlock)completed {
    NSLog(@"Message Working %@", memberDetail);
    
    NSString *params = [NSString string];
    params = [NSString stringWithString:memberDetail];
    [self postRequestWithParams: params completed:^(BOOL status){
        completed(status);
    }];
    
    NSLog(@"Params Working %@", params);
}
 */


//-(void)doSomethingWithCompletionHandler:(void(^)(BOOL status))handler {
    
  //  BOOL status = YES;
   // handler(status);

    
   // _completionHandler = [handler copy];
   // NSLog(@"Handler");
    
    
    
    
    
    
    
    
    
    //BOOL result = [self ];
    // Call completion handler.
    //_completionHandler(result);
    // Clean up.
    //[_completionHandler release];
    //_completionHandler = nil;
    
//}
 


@end
