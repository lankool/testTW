//
//  SceneDelegate.h
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 21/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

