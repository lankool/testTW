//
//  ListUser.h
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 28/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^completion)(NSMutableArray *listData);


@interface ListUser : NSObject

@property (strong, nonatomic) NSString *name;

//- (void)fetchCoursesUsingJSON :(NSString *)dataGet doSomethingWithCompletionHandler:(void(^)(BOOL status))handler;
- (void)fetchCoursesUsingJSON :(NSArray *)dataGet getMoreData:(completion)completionBlock;

@end


