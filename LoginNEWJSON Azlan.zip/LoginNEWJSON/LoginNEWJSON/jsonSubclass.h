//
//  jsonSubclass.h
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 23/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface jsonSubclass : NSObject

{
    void (^_completionHandler)(NSString* parameter);
}

//-(void)doSomethingWithCompletionHandler:(void(^)(BOOL))handler;

-(void)postingDetailswithJSON:(NSString *)dataPass doSomethingWithCompletionHandler:(void(^)(BOOL status))handler;
//+(void)showAlertTitle:(NSString *)title withMessage:(NSString *)message onView:(UIViewController *)viewController;

//+(void) alertStatus:(NSString *)msg :(NSString *)title onView:(UIViewController *)viewController;





@end


