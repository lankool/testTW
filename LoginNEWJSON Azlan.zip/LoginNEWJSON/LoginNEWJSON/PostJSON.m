//
//  PostJSON.m
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 21/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import "PostJSON.h"
#import "jsonSubclass.h"
#import "IndicatorView.h"
#import "ListUserNew.h"

@interface PostJSON () {
    
    NSString *post;
    NSString *dataPost;
    jsonSubclass *newclass;
    IndicatorView *spinnerClass;
    
}

@end

@implementation PostJSON

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    newclass = [[jsonSubclass alloc]init];
    spinnerClass = [[IndicatorView alloc]init];
    
    self.txtEmail.delegate = self;
    self.txtPassword.delegate = self;
    //[[NSNotificationCenter defaultCenter]
    //addObserver:self selector:@selector(triggerAction:) name:@"NotificationMessageEvent" object:nil];
    
    //[self postingDetailswithJSON];

}

/* #pragma mark - Notification
-(void) triggerAction:(NSNotification *) notification
{
    NSDictionary *dict = notification.userInfo;
   jsonSubclass *message = [dict valueForKey:@"message"];
    if (message != nil) {
        // do stuff here with your message data
        NSLog(@"Notificaton 1 %@", message);
    }
} */

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void) alertStatus:(NSString *)msg :(NSString *)title
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alertView = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
        [self presentViewController:alertView animated:YES completion:nil];
        
        UIAlertAction* okButton = [UIAlertAction
                                   actionWithTitle:@"Ok"
                                             style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action) {
                                              //Handle ok button
            
           
               [alertView dismissViewControllerAnimated:YES completion:nil];
            
                                           }];
           [alertView addAction:okButton];
        
    });
    
}

- (IBAction)loginClicked:(id)sender {
    
    
   post =[[NSString alloc] initWithFormat:@"email=%@&password=%@",self.txtEmail.text,self.txtPassword.text];
   // [newclass postingDetailswithJSON:post doSomethingWithCompletionHandler:sender];
    
 
    
        
        IndicatorView *customView = [[[NSBundle mainBundle] loadNibNamed:@"LoadingIndicator" owner:nil options:nil] firstObject];
        [customView threadStartAnimating];
        [self.view addSubview:customView];
    
        
    //[customView threadStopAnimating];
    //[self dismissViewControllerAnimated:YES completion:nil];
    //[customView threadStopAnimating];
   // [customView removeFromSuperview];
    
   /* IndicatorView *customViewNew = [[[NSBundle mainBundle] loadNibNamed:@"LoadingIndicator" owner:nil options:nil] firstObject];
       [customViewNew threadStopAnimating];
       [self.view addSubview:customViewNew];
    [customViewNew removeFromSuperview];
    [customView removeFromSuperview]; */
    
    
    //post = self.txtEmail.text;
    //[self alertStatus:@"Login Success BHA" :@"GOOD"];
    
    //NSLog(@"PostData: %@",post);
    //[jsonSubclass alertStatus:@"" :@"" onView:self];
    //pass function
    [newclass postingDetailswithJSON:post doSomethingWithCompletionHandler:^(BOOL status) {
       
        
        //[self alertStatus:@"Login Success" :@"Sucess" ];
        
         if(status == true)
        {
            NSLog(@"Success");
            //[self alertStatus:@"Login Success" :@"Sucess" ];
            
            dispatch_async(dispatch_get_main_queue(),^ {
                
                [customView removeFromSuperview];
                [self performSegueWithIdentifier:@"goMain" sender:self];
                /*ListUserNew* vc = (ListUserNew*)[[self storyboard] instantiateViewControllerWithIdentifier: @"navController"];
                [self.navigationController presentViewController:vc animated:YES completion: ^{
                   
                }];*/
               // [customView removeFromSuperview];
            });
            
          
        
        }
        else {
            NSLog(@"Fail");
            [self alertStatus:@"Login Fail" :@"Fail" ];
            dispatch_async(dispatch_get_main_queue(),^ {
            
             //  [customView removeFromSuperview];
            });
        }
}];
    
   
    
    
     //[self.navigationController popViewControllerAnimated:YES];
        
}



@end
