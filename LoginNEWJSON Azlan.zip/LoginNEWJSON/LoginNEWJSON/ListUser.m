//
//  ListUser.m
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 28/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import "ListUser.h"

@implementation ListUser

- (void)fetchCoursesUsingJSON :(NSArray *)dataGet getMoreData:(completion)completionBlock {
    NSLog(@"Fetching Courses");
//
    NSString *urlString = @"https://reqres.in/api/users?page=2";
    NSURL *url = [NSURL URLWithString:urlString];
    
    [[NSURLSession.sharedSession dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSLog(@"Finished fetching courses....");
        
        NSError *err;
        NSMutableDictionary *userJSON = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&err];
        
        //NSString *jsonfname = [NSString stringWithFormat:@" %@", [userJSON objectForKey:@"data"]];
        NSMutableArray *jsonName = [userJSON objectForKey:@"data"];
    
        NSLog(@"USER JSON %@", jsonName);
        
        if (err){
            NSLog(@"Failed to serialize into JSON: %@", err);
            return;
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {

               NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];

               if (statusCode == 200) {
                   NSLog(@"dataTaskWithRequest HTTP status code: %ld", (long)statusCode);
                    //NSArray *array = jsonName;
                   //NSDictionary *firstObject = jsonName[1];
                   //NSString *newsletter = firstObject[@"first_name"];
                 /*  NSDictionary *dict;
                   for (dict in jsonName) {
                       NSString *firstName = dict[@"first_name"];
                       NSString *email = dict[@"email"];
                       NSLog(@"First Name: %@", firstName);
                       NSLog(@"Email: %@", email);
                   }
                  */
                   
                   //NSLog(@"J: %@", newsletter);
                   //NSString *firstDescription = newsletter[@"description"];
                   
                   completionBlock(jsonName);
                   
                   NSLog(@"JSONNAME: %@", jsonName);
                   return;
               }
           }
       }] resume];
            }
        /*NSMutableArray<ListUser *> *users = NSMutableArray.new;
        for (NSDictionary *userDict in userJSON) { // Dalam array courseJSON ini ada Dictionary
            NSString *name = [NSString stringWithFormat:@" %@",userDict];
            //NSString *numberOfLessons = courseDict[@"number_of_lessons"];
            ListUser *userList = ListUser.new;
            userList.name = name;
            NSLog(@"USER LIST %@", name);
            //course.numberOfLessons = numberOfLessons;
            [users addObject:userList];
        } */
        
     /* NSMutableArray *userData = [NSMutableArray array];
      for (NSDictionary *UserDict in userJSON[@"data"]) {
          [userData addObject:u];
      } */
                
         

@end
 
