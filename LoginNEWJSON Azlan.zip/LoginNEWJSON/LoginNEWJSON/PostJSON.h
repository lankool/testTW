//
//  PostJSON.h
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 21/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface PostJSON : UIViewController <UITextFieldDelegate> {
    UINavigationController *refNavigationCon;
}

@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)loginClicked:(id)sender;

- (void) alertStatus:(NSString *)msg :(NSString *)title;


@property UIViewController *parent;


//-(void) triggerAction:(NSNotification *) notification;
//-(void)postingDetailswithJSON;


@end


