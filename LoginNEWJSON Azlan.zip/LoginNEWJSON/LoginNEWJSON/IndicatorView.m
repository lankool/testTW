//
//  IndicatorView.m
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 01/10/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import "IndicatorView.h"
#import "PostJSON.h"
#import "ListUser.h"

@implementation IndicatorView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(void)threadStartAnimating
{
    NSLog(@"start");
    [activityInd startAnimating];
    //[self performSelector:@selector(threadStopAnimating) withObject:nil afterDelay:10.0];
    //activityInd.hidden = NO;
}


-(void)threadStopAnimating
{
    NSLog(@"stop");
    [activityInd stopAnimating];
    activityInd.hidden = NO;

}

@end
