//
//  ListUserNew.m
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 28/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import "ListUserNew.h"
#import "ListUser.h"
#import "IndicatorView.h"
#import "ViewController.h"

@interface ListUserNew () <UINavigationControllerDelegate>

{
    
    ListUser *newUserClass;
    NSArray *dataGet;
    //NSMutableDictionary *jsonfname;
    NSMutableArray *arrName;
    IndicatorView *spinnerClass;
    ViewController *introPage;
    

}

@property (strong, nonatomic) NSArray<ListUser *> *users;

@end

@implementation ListUserNew


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //self.tableViewData.backgroundColor = [UIColor redColor];
    newUserClass = [[ListUser alloc]init];
    spinnerClass = [[IndicatorView alloc]init];
    introPage = [[ViewController alloc]init];
    self.tableViewData.dataSource = self;
    
     self.navigationItem.title = @"Contact Details";
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStylePlain target:self action:@selector(logOut:)];
    
   /* UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    [spinner setColor:[UIColor orangeColor]];
                 spinner.frame = CGRectMake(0, 0, 24, 24);
    [customVC addSubview:spinner];
                 [spinner startAnimating];
     */    
}

-(void)logOut:(UIBarButtonItem *)sender {
    
   // [self performSegueWithIdentifier:@"secondVC" sender:self];
  /*  ViewController* introP = (ViewController*)[[self storyboard] instantiateViewControllerWithIdentifier: @"introPage"];
    [self.navigationController presentViewController:introP animated:YES completion: nil]; */
    
    [self.navigationController popToRootViewControllerAnimated:YES];

    
}

- (void)viewDidAppear:(BOOL)animated
{
    
    
    IndicatorView *customView = [[[NSBundle mainBundle] loadNibNamed:@"LoadingIndicator" owner:nil options:nil] firstObject];
                      [customView threadStartAnimating];
                      [self.view addSubview:customView];
    
    [newUserClass fetchCoursesUsingJSON:dataGet getMoreData:^(NSMutableArray *listData) {

        NSLog(@"Array Listed %@", listData);
        
        self->arrName = [[NSMutableArray alloc]initWithArray:listData];
       /* if (listData) {
            
            
            //self.users = listData;
            
        } else {
            NSLog(@"Nil array");
        } */
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
        
           [self.tableViewData reloadData];
            [customView removeFromSuperview];
        
        });
        
        
             for ( NSMutableDictionary *arrName in listData) {
                 
                  NSString *firstName = arrName[@"first_name"];
                  NSString *email = arrName[@"email"];
                  NSLog(@"First Name: %@", firstName);
                  NSLog(@"Email: %@", email);
                 
                 
             }
        
        
    }];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

/*-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //[activityIndOld startAnimating];
    //[self performSelector:@selector(threadStopAnimating) withObject:nil afterDelay:5.0];
   // [self performSelectorOnMainThread:@selector(threadStopAnimating:) withObject:nil waitUntilDone:YES];
   // activityIndOld.hidden = NO;
}

-(void)threadStopAnimating
{
    //NSLog(@"stop");
    //[activityIndOld stopAnimating];
    //activityInd.hidden = YES;
} */

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    NSString *cellId = @"cellId";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId forIndexPath:indexPath];
    
   
    //[spinner release];
    
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    NSMutableArray *dict = [arrName objectAtIndex:indexPath.row];
    //cell.textLabel.text = [dict valueForKey:@"first_name"];
    //cell.textLabel.text = [dict valueForKey:@"last_name"];
    //cell.detailTextLabel.text = [dict valueForKey:@"email"];
    
    
    UILabel *lblFname = (UILabel *)[cell viewWithTag:1];
    //UILabel *lblLname = (UILabel *)[cell viewWithTag:2];
    UILabel *lblEmail = (UILabel *)[cell viewWithTag:3];
    UIImageView *img = (UIImageView *)[cell viewWithTag:4];
    
    
    img.layer.borderWidth = 2;
    img.layer.masksToBounds = YES;
    img.layer.borderColor = [UIColor whiteColor].CGColor;
    img.layer.cornerRadius = img.frame.size.width / 2;
    //img.layer.cornerRadius = 70;
    //img.layer.cornerRadius = 100;
    img.clipsToBounds = YES;
    
    NSString *combineString = [NSString stringWithFormat:@"%@ %@",[dict valueForKey:@"first_name"], [dict valueForKey:@"last_name"]];

    //Set the label
    lblFname.text = combineString;
    
    //lblFname.text = [dict valueForKey:@"first_name"];
    //lblLname.text = [dict valueForKey:@"last_name"];
    lblEmail.text = [dict valueForKey:@"email"];
    
    NSURL *url = [NSURL URLWithString:[dict valueForKey:@"avatar"]];
    NSData *imageData = [[NSData alloc]initWithContentsOfURL:url];
    //img = [UIImage imageWithData:imageData];
    [img setImage:[UIImage imageWithData:imageData]];

    
    
    //img.image = [dict valueForKey:@"avatar"];
    NSLog(@"AVATAR %@",url);
 
    
    return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrName.count;
}

- (CGFloat)tableView:(UITableView *)aTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

            return 100;
    }




@end
