//
//  ViewController.m
//  LoginNEWJSON
//
//  Created by BayoPay(M) SDN BHD on 21/09/2020.
//  Copyright © 2020 BayoPay(M) SDN BHD. All rights reserved.
//

#import "ViewController.h"
#import "PostJSON.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    
}


@end
